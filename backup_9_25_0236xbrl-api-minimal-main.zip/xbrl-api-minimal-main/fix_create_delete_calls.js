const fs = require('fs');

const filePath = './app/dashboard/AccountSettings.tsx';
let content = fs.readFileSync(filePath, 'utf8');

// 作成関数の修正
const createPattern = /const { data: result, error: invokeError } = await supabase\.functions\.invoke\('api-key-manager', {\s*body: {\s*action: 'create',[\s\S]*?}\s*}\);/;

const improvedCreate = `// Get fresh session for authentication
        const { data: { session }, error: sessionError } = await supabase.auth.getSession();
        
        if (sessionError || !session?.access_token) {
          throw new Error('Authentication required');
        }

        const { data: result, error: invokeError } = await supabase.functions.invoke('api-key-manager', {
          method: 'POST',
          headers: {
            Authorization: \`Bearer \${session.access_token}\`,
            'Content-Type': 'application/json'
          },
          body: {
            action: 'create',
            key_name: newKeyName.trim(),
            tier: 'free'
          }
        });`;

content = content.replace(createPattern, improvedCreate);

// 削除関数の修正
const deletePattern = /const { data: result, error: invokeError } = await supabase\.functions\.invoke\('api-key-manager', {\s*body: {\s*action: 'delete',[\s\S]*?}\s*}\);/;

const improvedDelete = `// Get fresh session for authentication
        const { data: { session }, error: sessionError } = await supabase.auth.getSession();
        
        if (sessionError || !session?.access_token) {
          throw new Error('Authentication required');
        }

        const { data: result, error: invokeError } = await supabase.functions.invoke('api-key-manager', {
          method: 'POST',
          headers: {
            Authorization: \`Bearer \${session.access_token}\`,
            'Content-Type': 'application/json'
          },
          body: {
            action: 'delete',
            key_id: deleteKeyId
          }
        });`;

content = content.replace(deletePattern, improvedDelete);

fs.writeFileSync(filePath, content, 'utf8');
console.log('✅ Create and Delete calls updated successfully');
