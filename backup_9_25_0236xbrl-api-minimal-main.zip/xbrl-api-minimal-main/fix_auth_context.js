const fs = require('fs');

const filePath = './app/auth/AuthContext.tsx';
let content = fs.readFileSync(filePath, 'utf8');

// 1. 環境変数の取得とエラーチェックを修正
const oldEnvCheck = `// Supabase設定 - 環境変数から取得
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);`;

const newEnvCheck = `// Supabase設定 - 環境変数から取得
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '';

// クライアント側でのみ環境変数チェックを実行
const createSupabaseClient = () => {
  if (typeof window !== 'undefined' && (!supabaseUrl || !supabaseAnonKey)) {
    throw new Error('Missing Supabase environment variables');
  }
  return createClient(supabaseUrl, supabaseAnonKey);
};

export const supabase = createSupabaseClient();`;

content = content.replace(oldEnvCheck, newEnvCheck);

fs.writeFileSync(filePath, content, 'utf8');
console.log('✅ AuthContext.tsx fixed successfully');
