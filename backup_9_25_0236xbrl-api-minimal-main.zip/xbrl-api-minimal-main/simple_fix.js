const fs = require('fs');

const filePath = './app/dashboard/AccountSettings.tsx';
let content = fs.readFileSync(filePath, 'utf8');

// 1. Import修正 - supabaseManagerをAuthContextのsupabaseに変更
content = content.replace(
  `import { supabaseManager } from '@/lib/infrastructure/supabase-manager';`,
  `import { supabase } from '@/app/auth/AuthContext';`
);

// 2. getBrowserClient()呼び出しを削除
content = content.replace(/const supabase = supabaseManager\.getBrowserClient\(\);/g, '');

// 3. functions.invokeに明示的なmethodとheadersを追加
content = content.replace(
  /await supabase\.functions\.invoke\('api-key-manager', \{\s*body: \{ action: 'list' \},[\s\S]*?method: 'POST'[\s\S]*?\}\)/,
  `await supabase.functions.invoke('api-key-manager', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: { action: 'list' }
      })`
);

// 4. create呼び出しの修正
content = content.replace(
  /await supabase\.functions\.invoke\('api-key-manager', \{\s*body: \{[\s\S]*?tier: 'free'[\s\S]*?\}\s*\}\)/,
  `await supabase.functions.invoke('api-key-manager', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: {
          action: 'create',
          key_name: newKeyName.trim(),
          tier: 'free'
        }
      })`
);

// 5. delete呼び出しの修正
content = content.replace(
  /await supabase\.functions\.invoke\('api-key-manager', \{\s*body: \{[\s\S]*?key_id: deleteKeyId[\s\S]*?\}\s*\}\)/,
  `await supabase.functions.invoke('api-key-manager', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: {
          action: 'delete',
          key_id: deleteKeyId
        }
      })`
);

fs.writeFileSync(filePath, content, 'utf8');
console.log('✅ Simple fix applied successfully');
