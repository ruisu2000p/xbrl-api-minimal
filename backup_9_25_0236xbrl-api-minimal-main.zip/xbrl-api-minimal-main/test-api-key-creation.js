// Test script for API key creation
import { createClient } from '@supabase/supabase-js'

const SUPABASE_URL = 'https://wpwqxhyiglbtlaimrjrx.supabase.co'
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

async function testApiKeyCreation() {
  console.log('🧪 Testing API Key Creation...\n')

  // Create Supabase client
  const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY)

  // Sign in (you'll need to replace with your credentials)
  const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
    email: 'your-email@example.com',
    password: 'your-password'
  })

  if (authError) {
    console.error('❌ Authentication failed:', authError)
    return
  }

  console.log('✅ Authenticated successfully\n')

  // Test 1: List existing keys
  console.log('📋 Test 1: Listing existing API keys...')
  const listResult = await supabase.functions.invoke('api-key-manager', {
    body: { action: 'list' }
  })
  console.log('List result:', JSON.stringify(listResult.data, null, 2))
  console.log('')

  // Test 2: Create a new key
  console.log('🔨 Test 2: Creating a new API key...')
  const createResult = await supabase.functions.invoke('api-key-manager', {
    body: {
      action: 'create',
      key_name: 'Test Key ' + new Date().toISOString(),
      tier: 'free'
    }
  })
  console.log('Create result:', JSON.stringify(createResult.data, null, 2))

  if (createResult.data?.newKey) {
    console.log('✅ New API key created successfully!')
    console.log('🔑 Key:', createResult.data.newKey)
  } else {
    console.error('❌ Failed to create API key - no newKey in response')
  }
}

// Run the test
testApiKeyCreation().catch(console.error)