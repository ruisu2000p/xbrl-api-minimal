-- Seed data for XBRL API Minimal
-- This file contains initial data for development and testing

-- Note: This is a placeholder seed file
-- Add any initial data needed for development here

-- Example: Insert test API keys (for development only)
-- INSERT INTO api_keys (user_id, key_hash, tier, name) 
-- VALUES (...) ON CONFLICT DO NOTHING;