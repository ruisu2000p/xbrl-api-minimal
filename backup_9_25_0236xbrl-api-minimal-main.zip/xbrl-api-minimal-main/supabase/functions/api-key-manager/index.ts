import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { corsHeaders } from '../_shared/cors.ts'

console.log('🚀 API Key Manager Function Starting (RPC Version)')

// base64url to base64 conversion
function b64urlToBase64(s: string) {
  return s.replace(/-/g, '+').replace(/_/g, '/').padEnd(Math.ceil(s.length / 4) * 4, '=')
}

// 軽量JWT解析（署名検証なし）
function getUserIdFromJWT(bearer?: string | null) {
  if (!bearer) return null
  const token = bearer.startsWith('Bearer ') ? bearer.slice(7) : bearer
  try {
    const [, payload] = token.split('.')
    if (!payload) return null
    const json = atob(b64urlToBase64(payload))
    const obj = JSON.parse(json)
    if (obj?.exp && Date.now() / 1000 > obj.exp) return null
    return obj?.sub ?? null
  } catch {
    return null
  }
}

function json(status: number, body: unknown) {
  // セキュリティ：エラーオブジェクトのスタックトレース情報を完全に除去
  let safeBody: unknown

  if (body instanceof Error) {
    safeBody = { error: body.message || 'An error occurred' }
  } else if (typeof body === 'object' && body !== null) {
    // オブジェクトの場合、Errorプロパティを再帰的にサニタイズ
    safeBody = sanitizeErrorProperties(body)
  } else {
    safeBody = body
  }

  return new Response(JSON.stringify(safeBody), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
  })
}

// エラープロパティを再帰的にサニタイズする関数
function sanitizeErrorProperties(obj: any): any {
  if (obj instanceof Error) {
    return { error: obj.message || 'An error occurred' }
  }

  if (Array.isArray(obj)) {
    return obj.map(item => sanitizeErrorProperties(item))
  }

  if (typeof obj === 'object' && obj !== null) {
    const sanitized: any = {}
    for (const [key, value] of Object.entries(obj)) {
      // stackプロパティは除外
      if (key === 'stack') continue
      sanitized[key] = sanitizeErrorProperties(value)
    }
    return sanitized
  }

  return obj
}

Deno.serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Debug request details
    console.log('📨 Request method:', req.method)
    console.log('📨 Request URL:', req.url)
    console.log('📨 Request headers:', Object.fromEntries(req.headers.entries()))

    // Environment check
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL')
    const SERVICE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')

    if (!SUPABASE_URL || !SERVICE_KEY) {
      console.error('❌ Missing environment variables')
      return json(500, { error: 'Missing environment variables' })
    }

    console.log('✅ Environment variables OK')

    // Initialize Supabase client (public schema only - RPC handles private access)
    const admin = createClient(SUPABASE_URL, SERVICE_KEY, {
      auth: { persistSession: false },
      global: { headers: { 'X-Client-Info': 'api-key-manager/1.0.0' } }
    })

    // Extract user ID from JWT
    const authHeader = req.headers.get('authorization') || req.headers.get('Authorization')
    const userId = getUserIdFromJWT(authHeader)

    if (!userId) {
      console.error('❌ Invalid or missing JWT token')
      return json(401, { error: 'Invalid or expired token' })
    }

    console.log('✅ Authenticated user:', userId)

    // Parse request body
    let body: any = {}
    let rawBody: string | null = null
    try {
      const contentType = req.headers.get('content-type') || ''
      console.log('📨 Content-Type:', contentType)

      if (req.body) {
        rawBody = await req.text()
        console.log('📨 Raw body:', rawBody)

        if (rawBody && contentType.includes('application/json')) {
          body = JSON.parse(rawBody)
        }
      }
    } catch (e) {
      console.log('⚠️ Body parsing failed:', e)
      console.log('⚠️ Raw body was:', rawBody)
    }

    console.log('📥 Parsed body:', JSON.stringify(body))
    console.log('📥 Body type:', typeof body)
    console.log('📥 Body keys:', body ? Object.keys(body) : 'null')

    // Check if body has a nested 'body' property (from supabase.functions.invoke)
    let actualBody = body
    if (body && typeof body === 'object' && 'body' in body && !('action' in body)) {
      console.log('📦 Detected nested body structure, extracting inner body')
      actualBody = body.body
    }

    console.log('📦 Actual body:', JSON.stringify(actualBody))
    const action = actualBody?.action || 'list'
    console.log('🎯 Final Action:', action)

    // Handle list action
    if (action === 'list') {
      console.log('📋 Fetching API keys via RPC...')

      const { data, error } = await admin.rpc('api_keys_list', {
        p_user_id: userId
      })

      if (error) {
        console.error('❌ RPC error (list):', error)
        return json(500, {
          error: 'Database error',
          details: error.message,
          code: error.code,
          hint: error.hint
        })
      }

      console.log('✅ Found API keys:', data?.length || 0)
      return json(200, { success: true, keys: data || [] })
    }

    // Handle create action
    if (action === 'create') {
      const { key_name, tier = 'free' } = actualBody

      console.log('🔨 Create action - key_name:', key_name, 'tier:', tier)

      if (!key_name || typeof key_name !== 'string') {
        console.error('❌ Invalid key_name:', key_name)
        return json(400, { error: 'key_name is required and must be a string' })
      }

      console.log('🔨 Creating new API key...')

      // Generate API key
      const chars = 'abcdefghijklmnopqrstuvwxyz0123456789'
      const array = new Uint8Array(32)
      crypto.getRandomValues(array)

      let apiKey = 'xbrl_v1_'
      for (let i = 0; i < 32; i++) {
        apiKey += chars[array[i] % chars.length]
      }

      // Generate SHA-256 hash
      const hashBuffer = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(apiKey))
      const keyHash = Array.from(new Uint8Array(hashBuffer))
        .map(b => b.toString(16).padStart(2, '0'))
        .join('')

      const keyPrefix = apiKey.substring(0, 12)

      console.log('🔑 Generated key with prefix:', keyPrefix)

      const { data, error } = await admin.rpc('api_keys_insert', {
        p_user_id: userId,
        p_name: key_name.trim(),
        p_tier: tier,
        p_key_hash: keyHash,
        p_key_prefix: keyPrefix
      })

      if (error) {
        console.error('❌ RPC error (insert):', error)
        return json(500, {
          error: 'Database error',
          details: error.message,
          code: error.code,
          hint: error.hint
        })
      }

      console.log('✅ API key created successfully')
      console.log('📦 RPC response data:', data)

      // RPCが単一行を返す場合の対応
      const row = Array.isArray(data) ? data[0] : data

      return json(200, {
        success: true,
        newKey: apiKey,  // フロントエンドが期待するフィールド名に変更
        apiKey: apiKey,  // 後方互換性のため残す
        keyId: row?.id,
        name: row?.name,
        tier: row?.tier,
        message: 'このAPIキーは一度だけ表示されます。安全な場所に保管してください。'
      })
    }

    // Handle delete action
    if (action === 'delete') {
      const { key_id } = actualBody

      console.log('🗑️ Delete action - key_id:', key_id)

      if (!key_id) {
        console.error('❌ Invalid key_id:', key_id)
        return json(400, { error: 'key_id is required' })
      }

      console.log('🗑️ Deleting API key:', key_id)

      const { error } = await admin.rpc('api_keys_delete', {
        p_user_id: userId,
        p_key_id: key_id
      })

      if (error) {
        console.error('❌ RPC error (delete):', error)
        return json(500, {
          error: 'Database error',
          details: error.message,
          code: error.code,
          hint: error.hint
        })
      }

      console.log('✅ API key deleted successfully')

      return json(200, {
        success: true,
        message: 'APIキーが正常に削除されました'
      })
    }

    // Unknown action
    return json(400, { error: 'Unknown action', action })

  } catch (error) {
    console.error('❌ Unhandled error:', error)
    return json(500, {
      error: 'Internal server error',
      details: error instanceof Error ? error.message : 'Unknown error'
    })
  }
})