-- ============================================
-- 匿名アクセスを完全に排除するRLSポリシー更新
-- 実行日: 2025-01-23
-- 目的: 匿名サインインOFF後の完全なセキュリティ強化
-- ============================================

-- ============================================
-- 1. Storageポリシーの更新
-- ============================================

-- markdown-filesバケット: 認証済みユーザーのみ閲覧可能
DROP POLICY IF EXISTS "Public read access to markdown files" ON storage.objects;
DROP POLICY IF EXISTS "Anonymous read access to markdown files" ON storage.objects;

CREATE POLICY "Authenticated users can read markdown files"
ON storage.objects
FOR SELECT
TO authenticated
USING (bucket_id = 'markdown-files');

-- ============================================
-- 2. Private スキーマのテーブル
-- ============================================

-- api_keys: 認証済みユーザーのみ（既存ポリシーの確認と更新）
DROP POLICY IF EXISTS "Users can view own API keys" ON private.api_keys;
CREATE POLICY "Authenticated users can view own API keys"
ON private.api_keys
FOR SELECT
TO authenticated
USING (user_id = (SELECT auth.uid()));

DROP POLICY IF EXISTS "Users can create own API keys" ON private.api_keys;
CREATE POLICY "Authenticated users can create own API keys"
ON private.api_keys
FOR INSERT
TO authenticated
WITH CHECK (user_id = (SELECT auth.uid()));

DROP POLICY IF EXISTS "Users can update own API keys" ON private.api_keys;
CREATE POLICY "Authenticated users can update own API keys"
ON private.api_keys
FOR UPDATE
TO authenticated
USING (user_id = (SELECT auth.uid()));

DROP POLICY IF EXISTS "Users can delete own API keys" ON private.api_keys;
CREATE POLICY "Authenticated users can delete own API keys"
ON private.api_keys
FOR DELETE
TO authenticated
USING (user_id = (SELECT auth.uid()));

-- api_key_usage_logs: 認証済みユーザーのみ
DROP POLICY IF EXISTS "Users can view own API key logs" ON private.api_key_usage_logs;
CREATE POLICY "Authenticated users can view own API key logs"
ON private.api_key_usage_logs
FOR SELECT
TO authenticated
USING (
    api_key_id IN (
        SELECT id FROM private.api_keys
        WHERE user_id = (SELECT auth.uid())
    )
);

-- api_key_rate_limits: 認証済みユーザーのみ
DROP POLICY IF EXISTS "Users can view rate limits for own API keys" ON private.api_key_rate_limits;
CREATE POLICY "Authenticated users can view own rate limits"
ON private.api_key_rate_limits
FOR SELECT
TO authenticated
USING (
    api_key_id IN (
        SELECT id FROM private.api_keys
        WHERE user_id = (SELECT auth.uid())
    )
);

DROP POLICY IF EXISTS "Users can manage rate limits for own API keys" ON private.api_key_rate_limits;
CREATE POLICY "Authenticated users can manage own rate limits"
ON private.api_key_rate_limits
FOR ALL
TO authenticated
USING (
    api_key_id IN (
        SELECT id FROM private.api_keys
        WHERE user_id = (SELECT auth.uid())
    )
);

-- ============================================
-- 3. Public スキーマのテーブル（存在する場合）
-- ============================================

-- markdown_files_metadata: 認証済みユーザーのみ読み取り可能
ALTER TABLE IF EXISTS public.markdown_files_metadata ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Anonymous can read metadata" ON public.markdown_files_metadata;
DROP POLICY IF EXISTS "Public read access" ON public.markdown_files_metadata;

CREATE POLICY IF NOT EXISTS "Authenticated users can read metadata"
ON public.markdown_files_metadata
FOR SELECT
TO authenticated
USING (true);  -- すべての認証済みユーザーがメタデータを閲覧可能

-- company_master: 認証済みユーザーのみ読み取り可能
ALTER TABLE IF EXISTS public.company_master ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Anonymous can read company data" ON public.company_master;
DROP POLICY IF EXISTS "Public read access" ON public.company_master;

CREATE POLICY IF NOT EXISTS "Authenticated users can read company data"
ON public.company_master
FOR SELECT
TO authenticated
USING (true);

-- company_directory_mapping: 認証済みユーザーのみ読み取り可能
ALTER TABLE IF EXISTS public.company_directory_mapping ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Anonymous can read directory mapping" ON public.company_directory_mapping;
DROP POLICY IF EXISTS "Public read access" ON public.company_directory_mapping;

CREATE POLICY IF NOT EXISTS "Authenticated users can read directory mapping"
ON public.company_directory_mapping
FOR SELECT
TO authenticated
USING (true);

-- ============================================
-- 4. Cronジョブ管理テーブル（存在する場合）
-- ============================================

-- managed_cron_jobs: 認証済みユーザーのみ
ALTER TABLE IF EXISTS public.managed_cron_jobs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Anon users have no access" ON public.managed_cron_jobs;
DROP POLICY IF EXISTS "Users can view own cron jobs" ON public.managed_cron_jobs;

CREATE POLICY IF NOT EXISTS "Authenticated users can view own cron jobs"
ON public.managed_cron_jobs
FOR SELECT
TO authenticated
USING (user_id = (SELECT auth.uid()));

CREATE POLICY IF NOT EXISTS "Authenticated users can create own cron jobs"
ON public.managed_cron_jobs
FOR INSERT
TO authenticated
WITH CHECK (user_id = (SELECT auth.uid()));

CREATE POLICY IF NOT EXISTS "Authenticated users can update own cron jobs"
ON public.managed_cron_jobs
FOR UPDATE
TO authenticated
USING (user_id = (SELECT auth.uid()));

CREATE POLICY IF NOT EXISTS "Authenticated users can delete own cron jobs"
ON public.managed_cron_jobs
FOR DELETE
TO authenticated
USING (user_id = (SELECT auth.uid()));

-- cron_job_logs: 認証済みユーザーのみ
ALTER TABLE IF EXISTS public.cron_job_logs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Anon users have no access to logs" ON public.cron_job_logs;
DROP POLICY IF EXISTS "Users can view logs for own cron jobs" ON public.cron_job_logs;

CREATE POLICY IF NOT EXISTS "Authenticated users can view own cron logs"
ON public.cron_job_logs
FOR SELECT
TO authenticated
USING (
    job_id IN (
        SELECT id FROM public.managed_cron_jobs
        WHERE user_id = (SELECT auth.uid())
    )
);

-- ============================================
-- 5. 権限の明示的な取り消し（念のため）
-- ============================================

-- anonロールから主要テーブルへのアクセスを明示的に取り消し
REVOKE ALL ON ALL TABLES IN SCHEMA private FROM anon;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA private FROM anon;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA private FROM anon;

-- publicスキーマの機密テーブルからもanonアクセスを制限
REVOKE ALL ON TABLE IF EXISTS public.managed_cron_jobs FROM anon;
REVOKE ALL ON TABLE IF EXISTS public.cron_job_logs FROM anon;

-- ============================================
-- 6. 関数の権限設定
-- ============================================

-- verify_api_key_hash関数: authenticatedとservice_roleのみ実行可能
REVOKE ALL ON FUNCTION private.verify_api_key_hash FROM anon;
GRANT EXECUTE ON FUNCTION private.verify_api_key_hash TO authenticated, service_role;

-- その他のプライベート関数も同様に設定
REVOKE ALL ON FUNCTION IF EXISTS private.log_api_key_usage FROM anon;
GRANT EXECUTE ON FUNCTION IF EXISTS private.log_api_key_usage TO authenticated, service_role;

-- ============================================
-- 完了メッセージ
-- ============================================
DO $$
BEGIN
    RAISE NOTICE '✅ 匿名アクセスの排除が完了しました';
    RAISE NOTICE '✅ すべてのテーブルが認証済みユーザーのみアクセス可能になりました';
    RAISE NOTICE '✅ Edge Functionを通じたJWT認証が必須となりました';
END $$;