const fs = require('fs');

const filePath = './app/dashboard/AccountSettings.tsx';
let content = fs.readFileSync(filePath, 'utf8');

// 1. Import修正の確認
if (!content.includes('import { supabase } from')) {
  content = content.replace(
    /import { supabaseManager } from '@\/lib\/infrastructure\/supabase-manager';/,
    "import { supabase } from '@/app/auth/AuthContext';"
  );
}

// 2. 変数の重複宣言を修正 - sessionとsessionErrorをユニークにする
let sessionCounter = 1;
content = content.replace(/const { data: { session }, error: sessionError }/g, (match) => {
  const replacement = `const { data: { session: session${sessionCounter} }, error: sessionError${sessionCounter} }`;
  sessionCounter++;
  return replacement;
});

// 3. session変数の参照も更新
sessionCounter = 1;
content = content.replace(/if \(sessionError \|\| !session\?\.access_token\)/g, (match) => {
  const replacement = `if (sessionError${sessionCounter} || !session${sessionCounter}?.access_token)`;
  sessionCounter++;
  return replacement;
});

// 4. Authorization headerの参照も更新  
sessionCounter = 1;
content = content.replace(/Authorization: `Bearer \${session\.access_token}`/g, (match) => {
  const replacement = `Authorization: \`Bearer \${session${sessionCounter}.access_token}\``;
  sessionCounter++;
  return replacement;
});

// 5. getBrowserClient()の削除されたコメントを確認
content = content.replace(/\/\/ Direct browser client from AuthContext/g, '');

fs.writeFileSync(filePath, content, 'utf8');
console.log('✅ TypeScript errors fixed');
