// テストユーザーを作成するスクリプト
const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = 'https://wpwqxhyiglbtlaimrjrx.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Indwd3F4aHlpZ2xidGxhaW1yanJ4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTgyMTk1NDEsImV4cCI6MjA3Mzc5NTU0MX0.aGMCRtTRIbdUMRTdJ7KFZ7oJ2krkD7QWzUEcTs7Jlfs';

const supabase = createClient(supabaseUrl, supabaseAnonKey);

async function createTestUser() {
  console.log('Creating test user...');

  const email = 'test@example.com';
  const password = 'Test123456!';

  try {
    // サインアップを試みる
    const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
      email: email,
      password: password,
      options: {
        data: {
          name: 'Test User',
          company: 'Test Company'
        }
      }
    });

    if (signUpError) {
      if (signUpError.message.includes('already registered')) {
        console.log('User already exists. Trying to sign in...');

        // 既存ユーザーでログイン
        const { data: signInData, error: signInError } = await supabase.auth.signInWithPassword({
          email: email,
          password: password
        });

        if (signInError) {
          console.error('Sign in error:', signInError);
          process.exit(1);
        }

        console.log('Successfully signed in!');
        console.log('Email:', email);
        console.log('Password:', password);
        console.log('User ID:', signInData.user?.id);
      } else {
        console.error('Sign up error:', signUpError);
        process.exit(1);
      }
    } else {
      console.log('Test user created successfully!');
      console.log('Email:', email);
      console.log('Password:', password);
      console.log('User ID:', signUpData.user?.id);
      console.log('Note: Check your email for confirmation if email confirmation is required.');
    }

    console.log('\nYou can now login at: https://xbrl-api-minimal.vercel.app/auth/login');
    console.log('Use the credentials above to log in.');

  } catch (error) {
    console.error('Unexpected error:', error);
    process.exit(1);
  }
}

createTestUser();