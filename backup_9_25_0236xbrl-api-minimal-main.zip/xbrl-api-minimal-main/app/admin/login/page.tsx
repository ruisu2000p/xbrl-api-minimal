'use client';

export default function AdminLoginPage() {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="bg-white p-8 rounded-lg shadow-lg max-w-md w-full">
        <h1 className="text-2xl font-bold mb-4">Admin Login</h1>
        <p className="text-gray-600">This page is under construction.</p>
      </div>
    </div>
  );
}